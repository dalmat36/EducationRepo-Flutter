package com.example.coronavirusapp

import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.app.FlutterActivity
import io.flutter.plugins.GeneratedPluginRegistrant

class MainActivity: FlutterActivity() {
}
